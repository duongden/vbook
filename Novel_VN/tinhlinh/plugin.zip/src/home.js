function execute() {
    return Response.success([
        { title: "Sủng", input: "/ngon-tinh-sung", script: "gen.js" },
        { title: "Ngược", input: "/ngon-tinh-nguoc", script: "gen.js" },
        { title: "Nữ tôn", input: "/nu-ton", script: "gen.js" },
        { title: "Cung đấu", input: "/cung-dau", script: "gen.js" },
        { title: "Bách Hợp", input: "/bach-hop", script: "gen.js" },
        { title: "Đam mỹ", input: "/dam-my", script: "gen.js" },
        { title: "Điền văn", input: "/dien-van", script: "gen.js" },
        { title: "Dị thế", input: "/di-the", script: "gen.js" },
        { title: "Xuyên không", input: "/xuyen-khong", script: "gen.js" },
        { title: "Trùng sinh", input: "/trung-sinh", script: "gen.js" },
        { title: "Đồng nhân", input: "/dong-nhan", script: "gen.js" },
        { title: "Huyền huyễn", input: "/huyen-huyen", script: "gen.js" },
        { title: "Khác", input: "/khac", script: "gen.js" }
    ])
}
