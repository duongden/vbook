load('config.js');

function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return null;

    let doc = response.html();
    const result = [];

    doc.select('div.float-menu.genre-menu a.genre-item-block').forEach(function(e) {
        const title = e.text().trim();         // tiêu đề thể loại
        const href  = e.attr('href');          // đường dẫn lọc thể loại

        result.push({
            title:  title,
            input:  href,
            script: "gen2.js"
        });
    });

    return Response.success(result);
}
