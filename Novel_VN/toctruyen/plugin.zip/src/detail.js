load('config.js');

const execute = url => {
  // Quy về link đầy đủ
  url = url.startsWith('http') ? url : BASE_URL + url;
  const resp = fetch(url);
  if (!resp.ok) return null;

  const doc = resp.html();

  // Hàm clean: loại bỏ mọi '/', rồi trim
  function clean(str) {
    return str.replace(/\//g, '').trim();
  }

  // 1) Name
  const name = clean(doc.select('div.novel-header h1').text());

  // 2) Cover
  let cover = doc
    .select('div.novel-header .novel-thumb')
    .attr('data-original');
  if (!cover.startsWith('http')) cover = BASE_URL + cover;

  // 3) Lấy các thông tin trong bảng info-card
  const info = key =>
    clean(doc.select(`div.novel-info-card .tr:contains(${key}) .td`).text());

  const author        = info('Tác giả');
  const poster        = clean(
    doc
      .select('div.novel-info-card .tr:contains(Người đăng) a')
      .text()
  );
  const status        = info('Trạng thái');
  const totalChapters = info('Số chương dự kiến');
  const views         = clean(doc.select('#novel-view').text());

  // 4) Mô tả: lấy plain-text rồi clean, nạp lại với <br>
  const rawDesc = doc.select('#description').text();
  const description = clean(rawDesc)
    .replace(/\r?\n+/g, '<br>');

  // 5) Genres — chỉ clean phần title, giữ nguyên href
  const genres = [];
  doc.select('div.detail-genres a').forEach(e => {
    let href = e.attr('href');
    if (!href.startsWith('http')) href = BASE_URL + href;
    genres.push({
      title:  clean(e.text()),
      input:  href,
      script: 'gen.js'
    });
  });

  // 6) Lấy lastUpdate / lastChapter
  const lastUpdate  = clean(
    doc
      .select('section:has(#description) h4.header-sub')
      .first()
      .text()
  );
  const lastChapter = clean(
    doc
      .select('div.novel-info-card .tr:contains(Đọc ngay) a')
      .text()
  );

  // 7) Build detail string
  const detail = [
    `Tác giả: ${author}`,
    `Người đăng: ${poster}`,
    `Tình trạng: ${status}`,
    `Tổng chương: ${totalChapters}`,
    `Chương mới nhất: ${lastChapter}`,
    `Cập nhật: ${lastUpdate}`,
    `Lượt đọc: ${views}`
  ].join('<br>');

  return Response.success({
    name,
    cover,
    author,
    poster,
    status,
    genres,
    description,
    detail,
    host: BASE_URL
  });
}
