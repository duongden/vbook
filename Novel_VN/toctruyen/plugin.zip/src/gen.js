// gen.js
load('config.js');

function execute(url, page) {
    let currentPage = page && page !== '1' ? page : '1';
    let fullUrl = BASE_URL + url + (currentPage !== '1' ? '?page=' + currentPage : '');

    let resp = fetch(fullUrl);
    if (!resp.ok) return null;
    let doc = resp.html();

    // Lấy danh sách kết quả
    let data = [];
    doc.select('#result .card-item').forEach(e => {
        let a     = e.select('a').first();
        let cover = e.select('.img.lazy').attr('data-original') || '';
        if (cover && !/^https?:\/\//.test(cover)) cover = BASE_URL + cover;
        data.push({
            name:        a.select('h3.card-title').text().trim(),
            link:        a.attr('href'),
            cover:       cover,
            description: e.select('p.card-subtitle').text().trim(),
            host:        BASE_URL
        });
    });

    // Tính next page = currentPage + 1
    let next = String(parseInt(currentPage, 10) + 1);

    return Response.success(data, next);
}
