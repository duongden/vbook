function execute(url) {
    var doc = Http.get(url).html();
    if (doc) {
        var htm = doc.select(".novel-reading-content").html();
        return Response.success(cleanHtml(htm));
    }
    return null;
}

function cleanHtml(htm) {
    // thay ƣ thành ư
    htm = htm.replace(/ƣ/g, 'ư');

    // loại bỏ mọi dấu gạch chéo
    htm = htm.replace(/\//g, '');

    // cắt <br> dư thừa ở đầu/cuối
    htm = htm.replace(/(^(<br>\s*)+|(<br>\s*)+$)/gm, '');

    // gom nhiều <br> liền thành 1
    htm = htm.replace(/(<br>\s*){2,}/gm, '<br>');

    // xóa các thẻ <a> rác
    htm = htm.replace(/<a[^>]*>([^<]+)<\/a>/g, '');

    // xóa các entity HTML cơ bản
    htm = htm.replace(/&(nbsp|amp|quot|lt|gt);/g, "");

    return htm;
}
