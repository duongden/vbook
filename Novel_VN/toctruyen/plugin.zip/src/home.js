function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "/tim-kiem.html", script: "gen.js" },
    ])
}
