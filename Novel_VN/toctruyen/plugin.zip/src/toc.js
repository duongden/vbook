// toc.js
load('config.js');

function execute(url) {
    // 1. Chuẩn hóa URL
    if (!/^https?:\/\//i.test(url)) {
        url = BASE_URL + url;
    }

    // 2. Tách pid trực tiếp từ đường dẫn /truyen/<pid>/...
    var m = url.match(/\/truyen\/([^\/]+)/);
    if (!m) return null;
    var pid = m[1];

    // 3. Gọi API lấy danh sách chương
    var resp = fetch(BASE_URL + '/content/subitems?pid=' + pid);
    if (!resp.ok) return null;
    var json = resp.json();
    var items = json.data && json.data.e;
    if (!Array.isArray(items)) return null;

    // 4. Đảo ngược để Chương 1 lên trước và build kết quả
    var chapters = [];
    for (var i = items.length - 1; i >= 0; i--) {
        var it = items[i];
        chapters.push({
            name: it[2],
            url: it[3].indexOf('http') === 0
                ? it[3]
                : BASE_URL + it[3],
            host: BASE_URL
        });
    }

    return Response.success(chapters);
}
