load('config.js');

function execute(key, page) {
    const kw   = encodeURIComponent(key);
    const url  = BASE_URL + "/content/navSearch?kw=" + kw;
    const resp = fetch(url, {
        headers: {
            "accept":             "application/json, text/javascript, */*; q=0.01",
            "x-requested-with":   "XMLHttpRequest",
            "referer":            BASE_URL + "/tim-kiem"
        }
    });
    if (!resp.ok) return null;

    const json = resp.json();
    const items = json.items || [];
    const data = [];

    items.forEach(html => {
        const hrefM = html.match(/href="([^"]+)"/);
        if (!hrefM) return;

        let link = hrefM[1].trim();
        if (!/^https?:\/\//i.test(link)) link = BASE_URL + link;

        const coverM = html.match(/data-original="([^"]+)"/);
        let cover = coverM ? coverM[1].trim() : "";
        if (cover && !/^https?:\/\//i.test(cover)) cover = BASE_URL + cover;

        const nameM = html.match(/<div class="mb-1">([\s\S]*?)<\/div>/);
        const name = nameM ? nameM[1].trim() : "";

        const descM = html.match(/<div class="text-sub[^>]*>([\s\S]*?)<\/div>/);
        const description = descM ? descM[1].trim() : "";

        data.push({
            name,
            link,
            cover,
            description,
            host: BASE_URL
        });
    });

    return Response.success(data);
}
