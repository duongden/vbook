// gen2.js
load('config.js');

function execute(url, page) {
    // Xác định URL đầy đủ
    var fullUrl = url.startsWith('http') ? url : BASE_URL + url;
    var current = page && page !== '1' ? page : '1';

    // Chỉ thêm ?page= khi current > 1
    if (current !== '1') {
        fullUrl += (fullUrl.indexOf('?') > -1 ? '&' : '?') + 'page=' + current;
    }

    var resp = fetch(fullUrl, { method: 'GET' });
    if (!resp.ok) return null;
    var doc = resp.html();

    // Lấy danh sách truyện
    var data = [];
    doc.select('#result .card-item').forEach(function(e) {
        var a     = e.select('a').first();
        var cover = e.select('.img.lazy').attr('data-original') || '';
        if (cover.startsWith('/')) cover = BASE_URL + cover;

        data.push({
            name:        a.select('h3.card-title').text().trim(),
            link:        a.attr('href'),
            cover:       cover,
            description: e.select('p.card-subtitle').text().trim(),
            host:        BASE_URL
        });
    });

    // Tìm tất cả các page number trong pagination
    var pageNums = [];
    doc.select('section.text-center a.fv-button-small[href*="page="]').forEach(function(el) {
        var m = el.attr('href').match(/page=(\d+)/);
        if (m) {
            var num = parseInt(m[1], 10);
            if (pageNums.indexOf(num) === -1) pageNums.push(num);
        }
    });
    pageNums.sort(function(a, b){ return a - b });

    // Tìm next = số page nhỏ nhất > current
    var next = null;
    var currInt = parseInt(current, 10);
    for (var i = 0; i < pageNums.length; i++) {
        if (pageNums[i] > currInt) {
            next = String(pageNums[i]);
            break;
        }
    }

    return Response.success(data, next);
}
