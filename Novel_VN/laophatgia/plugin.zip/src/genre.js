load('config.js');

function execute() {
    // 1. Fetch trang chính
    var response = fetch(BASE_URL);
    if (!response.ok) return null;

    var doc = response.html();
    var result = [];

    var tags = doc.select('.widget_tag_cloud .tagcloud a.tag-cloud-link');
    for (var i = 0; i < tags.size(); i++) {
        var e = tags.get(i);
        var title = e.text().trim();
        var href  = e.attr('href');

        result.push({
            title:  title,
            input:  href,
            script: "zen.js"
        });
    }

    return Response.success(result);
}