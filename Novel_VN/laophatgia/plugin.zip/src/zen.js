load('config.js');
function execute(path, page) {
    if (!page) page = '1';

    var fetchUrl;
    if (path.indexOf('http') === 0) {
        if (page === '1') {
            fetchUrl = path;
        } else {
            fetchUrl = path.replace(/\/$/, '') + '/page/' + page + '/';
        }
    } else {
        // path là relative
        var base = BASE_URL.replace(/\/$/, '');
        if (page === '1') {
            fetchUrl = base + path;
        } else {
            fetchUrl = base + path.replace(/\/$/, '') + '/page/' + page + '/';
        }
    }

    var response = fetch(fetchUrl);
    if (!response.ok) return null;
    var doc = response.html();

    var list = [];
    var items = doc.select('.tab-content-wrap .page-item-detail');
    for (var i = 0; i < items.size(); i++) {
        var el = items.get(i);
        var a  = el.select('h3.h5 a').first();
        var ch = el.select('.list-chapter .chapter').first();
        list.push({
            name:        a.text().trim(),
            link:        a.attr('href'),
            description: ch ? ch.text().trim() : '',
            host:        BASE_URL
        });
    }

    var prevEl = doc.select('.nav-previous a').first();
    var nextPage = null;
    if (prevEl) {
        var href = prevEl.attr('href');
        var m = href.match(/\/page\/(\d+)\//);
        if (m) nextPage = m[1];
    }

    return Response.success(list, nextPage);
}