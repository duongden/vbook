load('config.js');
function execute(url) {
    var pageUrl = url.indexOf('http')===0?url:BASE_URL.replace(/\/$/, '')+url;
    var res = fetch(pageUrl);
    if (!res.ok) return null;
    var doc = res.html();

       let genres = [];
    doc.select('.genres-content a').forEach(e => {
        genres.push({
            title:  e.text(),
            input:  e.attr('href'),
            script: "zen.js"
        });
    });

    var title = doc.select('div.post-title h1').text().trim();
    var imgEl = doc.select('div.summary_image img').first();
    var coverSrc = imgEl.attr('data-src');
    var cover = coverSrc && coverSrc !== '' ? coverSrc : imgEl.attr('src');
    var author = doc.select(".post-content_item:contains(Tác giả) a").text().trim();
    var genresEls = doc.select(".post-content_item:contains(Thể loại) a");
    var genre = [];
    for(var i=0;i<genresEls.size();i++) genre.push(genresEls.get(i).text().trim());
    var status = doc.select(".post-content_item:contains(Tình trạng) .summary-content").text().trim();
    var rating = doc.select('.post-total-rating .score').text().trim();
    var desc = doc.select('.description-summary .summary__content').text().trim();
    var detail = 'Tác giả: '+author+'<br>Thể loại: '+genre.join(', ')+'<br>Tình trạng: '+status+'<br>Đánh giá: '+rating+'/5';
    return Response.success({name:title,cover:cover,author:author,description:desc,detail:detail,genres:genres,host:BASE_URL});
}