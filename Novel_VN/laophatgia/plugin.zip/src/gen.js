load('config.js');

function execute(path, page) {
    if (!page) page = '1';
    var base = BASE_URL.replace(/\/$/, '');
    var fetchUrl = base + path;
    if (page !== '1') {
        fetchUrl = base + '/page/' + page + '/';
    }

    var response = fetch(fetchUrl);
    if (!response.ok) return null;
    var doc = response.html();

    var list = [];
    var items = doc.select('.c-blog-listing.c-page__content.manga_content .page-item-detail');
    for (var i = 0; i < items.size(); i++) {
        var el = items.get(i);
        var a   = el.select('h3.h5 a').first();
        var ch  = el.select('.list-chapter .chapter').first();
        list.push({
            name:        a.text().trim(),
            link:        a.attr('href'),
            description: ch ? ch.text().trim() : '',
            host:        BASE_URL
        });
    }

    var nextLink = doc.select('.wp-pagenavi span.current + a').first();
    var nextPage = nextLink ? nextLink.text().trim() : null;

    return Response.success(list, nextPage);
}
