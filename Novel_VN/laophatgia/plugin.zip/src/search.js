load('config.js');

function execute(key, page) {
    if (!page) page = '1';

    var keyword = encodeURIComponent(key);
    var url = BASE_URL + "/tim-kiem?key_word=" + keyword + "&page=" + page;

    var response = fetch(url, {
        method: 'GET',
        headers: {
            "referer": BASE_URL + "/tim-kiem"
        }
    });

    if (!response.ok) return null;

    var doc = response.html();

    var data = [];
    var items = doc.select(".story-item-list");
    for (var i = 0; i < items.size(); i++) {
        var e = items.get(i);
        data.push({
            name: e.select(".story-name").text(),
            link: e.select("a.story-name").attr("href"),
            cover: e.select(".story-item-list__image img").attr("src"),
            description: e.select(".author-name").text(),
            host: BASE_URL
        });
    }

    var currentPage = parseInt(page);
    var next = (items.size() > 1) ? String(currentPage + 1) : null;

    return Response.success(data, next);
}
