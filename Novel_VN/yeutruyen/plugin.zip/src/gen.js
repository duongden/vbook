load('config.js');
function execute(url) {
    let response = fetch(BASE_URL);
    if (response.ok) {
        let doc = response.html();
        let novelList = [];

        doc.select('div.story-item-no-image').forEach(item => {
            let nameEl = item.select('h3 a.story-name').first();
            let descEl = item.select('div.story-item-no-image__chapters a').first();

            novelList.push({
                name:        nameEl.text().trim(),
                link:        nameEl.attr('href'),
                description: descEl ? descEl.text().trim() : '',
                host:        BASE_URL
            });
        });

        return Response.success(novelList);
    }
    return null;
}
