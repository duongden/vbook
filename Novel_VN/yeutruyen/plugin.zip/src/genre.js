load('config.js');

function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return null;
    console.log(BASE_URL)

    let doc = response.html();
    const result = [];

    // Chọn tất cả các liên kết thể loại trong menu "Thể loại"
    doc.select('ul.dropdown-menu-custom li a.dropdown-item').forEach(e => {
        let title = e.text().trim();
        let href  = e.attr('href');
        result.push({
            title:  title,
            input:  href,
            script: "zen.js"
        });
    });

    return Response.success(result);
}
