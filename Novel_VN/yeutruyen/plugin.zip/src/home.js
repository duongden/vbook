load('config.js');
function execute() {
    return Response.success([
        {title: "Truyện mới", input: BASE_URL, script: "gen.js"},
    ]);
}
