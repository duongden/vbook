// zen.js
load('config.js');

function execute(url, page) {
    if (!page) page = '1';
    let fullUrl = url;
    if (page !== '1') {
        fullUrl += (url.includes('?') ? '&' : '?') + 'page=' + page;
    }
    console.log(url)
    let response = fetch(fullUrl);
    if (!response.ok) return null;
    console.log(fullUrl)
    let doc = response.html();
    let data = [];

    doc.select('div.list-story-in-category div.story-item').forEach(item => {
        let aTag   = item.select('a.d-block').first();
        let title  = item.select('h3.story-item__name').text().trim();
        let cover  = item.select('div.story-item__image img').attr('src');

        let badges = [];
        item.select('div.list-badge span').forEach(b => badges.push(b.text().trim()));

        data.push({
            name:        title,
            link:        aTag   ? aTag.attr('href') : '',
            cover:       cover  || '',
            description: badges.join(' '),
            host:        BASE_URL
        });
    });

    // trang tiếp theo = page + 1
    let next = (parseInt(page, 10) + 1).toString();
    return Response.success(data, next);
}
