load('config.js');

function execute(url) {
    if (!url) return null;
    let doc = fetch(url).html();

    let name = doc.select('.story-detail__top .story-name').text().trim();

    let cover = doc.select('.story-detail__top--image img').attr('src');
    let authorEl = doc.select('.story-detail__bottom--info p.mb-1 a.hover-title').first();
    let author = authorEl ? authorEl.text().trim() : '';

    let description = doc
        .select('.story-detail__top--desc')

        .html()
        .trim();

    let categories = [];
    doc
      .select('.story-detail__bottom--info a.hover-title.me-1')
      .forEach(e => categories.push(e.text().trim().replace(/,$/, '')));

    let status = doc
      .select('p.mb-1 .text-info')
      .text()
      .trim();

    let detail =
        'Tác giả: '  + author + '<br>' +
        'Thể loại: ' + categories.join(', ') + '<br>' +
        'Trạng thái: ' + status;

    return Response.success({
        name:        name,
        cover:       cover,
        host:        BASE_URL,
        author:      author,
        description: description,
        detail:      detail
    });
}
