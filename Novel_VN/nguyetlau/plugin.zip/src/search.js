load('config.js');

function execute(key, page) {
    if (!page) page = '1';

    var keyword = encodeURIComponent(key);
    var url = "/novels?search=" + keyword + "&page=" + page;
    var pageJson = fetchInertia(url);
    if (!pageJson || !pageJson.props || !pageJson.props.novels) return null;

    var data = [];
    var items = pageJson.props.novels.data || [];
    for (var i = 0; i < items.length; i++) {
        var it = unwrapResource(items[i]);
        if (!it) continue;

        data.push({
            name: it.title || "",
            link: BASE_URL + "/novels/" + it.slug,
            cover: storageUrl(it.cover_image),
            description: it.author && it.author.name ? String(it.author.name) : "",
            host: BASE_URL
        });
    }

    var next = pageJson.props.novels.next_page_url ? String(parseInt(page, 10) + 1) : null;

    return Response.success(data, next);
}
