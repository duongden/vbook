load('config.js');

function execute(path) {
    if (!path) {
        path = '/novels';
    }
    var pageJson = fetchInertia(path);
    if (!pageJson) return Response.error("Không đọc được dữ liệu Inertia");

    var cats = [];
    if (pageJson.props && pageJson.props.categories && pageJson.props.categories.data) {
        cats = pageJson.props.categories.data;
    }

    var result = [];
    for (var i = 0; i < cats.length; i++) {
        var c = cats[i];
        result.push({
            title:  c.name,
            slug:   c.slug,
            count:  c.novels_count || 0,
            input:  '/novels?category=' + c.slug,
            script: 'gen.js'
        });
    }

    return Response.success(result);
}
