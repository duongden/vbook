var BASE_URL = "https://nguyetlau.top"

function cleanUrl(url) {
    if (!url) return "";
    return String(url).trim().replace(/[?#].*$/, "");
}

function absoluteUrl(url) {
    if (!url) return "";
    url = String(url).trim();
    if (url.indexOf("http://") === 0 || url.indexOf("https://") === 0) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    return BASE_URL + (url.charAt(0) === "/" ? url : "/" + url);
}

function storageUrl(path) {
    if (!path) return "";
    path = String(path).trim();
    if (path.indexOf("http://") === 0 || path.indexOf("https://") === 0) return path;
    if (path.indexOf("/") === 0) return BASE_URL + path;
    return BASE_URL + "/storage/" + path;
}

function unwrapResource(value) {
    if (value && value.data) return value.data;
    return value;
}

function parseInertiaPage(doc) {
    var appDiv = doc.select("div#app").first();
    if (!appDiv) return null;

    var dataPage = appDiv.attr("data-page");
    if (!dataPage) return null;

    try {
        return JSON.parse(dataPage);
    } catch (e) {
        dataPage = String(dataPage)
            .replace(/&quot;/g, '"')
            .replace(/&#34;/g, '"')
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');
        return JSON.parse(dataPage);
    }
}

function fetchInertia(path) {
    var url = absoluteUrl(path);
    var res = fetch(url, {
        headers: {
            "Accept": "text/html",
            "User-Agent": "Mozilla/5.0"
        }
    });
    if (!res.ok) return null;
    return parseInertiaPage(res.html());
}

function normalizeStatus(status) {
    status = status ? String(status) : "";
    if (status === "completed") return "Hoàn thành";
    if (status === "ongoing") return "Đang cập nhật";
    return status;
}

function chapterName(chapter) {
    var title = chapter && chapter.title ? String(chapter.title) : "";
    var number = chapter && chapter.chapter_number ? String(chapter.chapter_number) : "";
    if (!title && number) return "Chương " + number;
    if (title.toLowerCase().indexOf("chương") === 0 || title.toLowerCase().indexOf("chuong") === 0) return title;
    if (number && title !== number) return "Chương " + number + ": " + title;
    return title || ("Chương " + number);
}

function cleanVietnameseText(value) {
    if (typeof value !== "string") return value;
    var text = value;
    var letters = "A-Za-zÀ-ỹĐđ";
    var lowerLetters = "a-zà-ỹđ";
    var dot = new RegExp("([" + lowerLetters + "])\\.([" + lowerLetters + "])", "g");
    var slash = new RegExp("([" + letters + "])\\s*[/_-]+\\s*([" + letters + "])", "g");
    for (var i = 0; i < 6; i++) {
        text = text.replace(dot, "$1$2").replace(slash, "$1$2");
    }
    return text
        .replace(/\bgiếc\b/gi, "giết")
        .replace(/\bchếc\b/gi, "chết")
        .replace(/[ \t]+([,.!?;:])/g, "$1")
        .replace(/([.!?])([A-ZÀ-ỸĐ])/g, "$1 $2")
        .replace(/[ \t]{2,}/g, " ")
        .replace(/(?:\s*<br\s*\/?\>\s*){3,}/gi, "<br><br>")
        .replace(/^(?:\s*<br\s*\/?\>\s*)+|(?:\s*<br\s*\/?\>\s*)+$/gi, "")
        .trim();
}
