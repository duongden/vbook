load('config.js');
function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: "/novels?sort=latest_chapter", script: "gen.js"},
    ]);
}
