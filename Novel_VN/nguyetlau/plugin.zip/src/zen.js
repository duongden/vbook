load('config.js');

function execute(url, page) {
    var path = url || "/novels";
    if (page && String(page) !== "1") {
        path += (String(path).indexOf("?") >= 0 ? "&" : "?") + "page=" + page;
    }

    var pageJson = fetchInertia(path);
    if (!pageJson || !pageJson.props || !pageJson.props.novels) return null;

    var items = pageJson.props.novels.data || [];
    var data = [];
    for (var i = 0; i < items.length; i++) {
        var it = unwrapResource(items[i]);
        if (!it) continue;

        var categories = [];
        if (it.categories) {
            for (var j = 0; j < it.categories.length; j++) {
                if (it.categories[j] && it.categories[j].name) categories.push(String(it.categories[j].name));
            }
        }

        data.push({
            name: it.title || "",
            link: BASE_URL + "/novels/" + it.slug,
            cover: storageUrl(it.cover_image),
            description: categories.join(", "),
            host: BASE_URL
        });
    }

    var next = null;
    if (pageJson.props.novels.next_page_url) {
        var nextPage = parseInt(page || "1", 10) + 1;
        next = String(nextPage);
    }

    return Response.success(data, next);
}
