load('config.js');

function execute(url) {
    url = cleanChapUrl(url);
    var pageJson = fetchInertia(url);
    if (!pageJson || !pageJson.props || !pageJson.props.chapter) return null;

    var chapter = unwrapResource(pageJson.props.chapter);
    var content = chapter && chapter.content ? String(chapter.content) : "";
    return Response.success(cleanVietnameseText(content));
}

function cleanChapUrl(url) {
    return cleanUrl(url);
}
