load('config.js');

function execute(url) {
    url = cleanUrl(url);
    var pageJson = fetchInertia(url);
    if (!pageJson || !pageJson.props) return null;

    var novel = pageJson.props.novel ? unwrapResource(pageJson.props.novel) : null;
    var slug = novel && novel.slug ? String(novel.slug) : "";
    if (!slug) {
        var m = String(url).match(/\/novels\/([^\/]+)/);
        if (m) slug = m[1];
    }

    var chapters = [];
    if (pageJson.props.chapters && pageJson.props.chapters.data) {
        chapters = pageJson.props.chapters.data;
    } else if (novel && novel.chapters) {
        chapters = novel.chapters;
    }

    var list = [];
    for (var i = 0; i < chapters.length; i++) {
        var chapter = unwrapResource(chapters[i]);
        if (!chapter) continue;

        var number = chapter.chapter_number || chapter.number || chapter.id;
        if (!number) continue;

        list.push({
            name: chapterName(chapter),
            url: BASE_URL + "/novels/" + slug + "/chapter/" + number,
            host: BASE_URL
        });
    }

    list.sort(function(a, b) {
        return chapterSortKey(a) - chapterSortKey(b);
    });

    return Response.success(list);
}

function chapterSortKey(ch) {
    var name = String(ch.name || "").toLowerCase();
    var m = name.match(/chương\s*(\d+)|chuong[-–\s]*(\d+)/);
    if (m) return parseInt(m[1] || m[2], 10);

    m = String(ch.url || "").match(/\/chapter\/([^\/]+)/);
    if (m && !isNaN(parseFloat(m[1]))) return parseFloat(m[1]);

    if (name.indexOf('cuối') >= 0 || name.indexOf('cuoi') >= 0) return 1000000;
    if (name.indexOf('ngoại') >= 0 || name.indexOf('ngoai') >= 0) return 10000000;
    return 100000000;
}
