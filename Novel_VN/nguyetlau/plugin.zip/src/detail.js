load('config.js');

function getHost(url) {
    var m = String(url).match(/^(https?:\/\/[^\/]+)/);
    return m ? m[1] : BASE_URL;
}

function execute(url) {
    if (!url) return null;
    url = cleanUrl(url);

    var pageJson = fetchInertia(url);
    if (!pageJson || !pageJson.props || !pageJson.props.novel) {
        return Response.error("Không đọc được detail: " + url);
    }

    var novel = unwrapResource(pageJson.props.novel);
    if (!novel) return Response.error("Không tìm thấy dữ liệu truyện");

    var author = "";
    if (novel.author && novel.author.name) author = String(novel.author.name);
    if (!author && novel.author_name) author = String(novel.author_name);
    author = cleanVietnameseText(author);

    var categories = [];
    if (novel.categories) {
        for (var i = 0; i < novel.categories.length; i++) {
            if (novel.categories[i] && novel.categories[i].name) categories.push(cleanVietnameseText(String(novel.categories[i].name)));
        }
    }

    var status = normalizeStatus(novel.status);
    var latest = "";
    if (novel.latest_chapter) latest = chapterName(novel.latest_chapter);
    var host = getHost(url);

    var detail =
        'Tác giả: '  + author + '<br>' +
        'Thể loại: ' + categories.join(', ') + '<br>' +
        'Trạng thái: ' + status +
        (latest ? '<br>Chương mới: ' + latest : '');

    return Response.success({
        name:        cleanVietnameseText(novel.title || ""),
        cover:       storageUrl(novel.cover_image),
        host:        host,
        author:      author,
        description: cleanVietnameseText(novel.description || ""),
        detail:      cleanVietnameseText(detail),
        ongoing:     String(novel.status).indexOf('completed') < 0 && status.indexOf('Hoàn') < 0
    });
}
