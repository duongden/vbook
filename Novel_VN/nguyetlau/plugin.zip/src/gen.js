load('config.js');

function execute(path) {
    var pageJson = fetchInertia(path || "/novels?sort=latest_chapter");
    if (!pageJson) return Response.error("Không đọc được dữ liệu Inertia");

    var items = [];
    if (pageJson.props && pageJson.props.novels && pageJson.props.novels.data) {
        items = pageJson.props.novels.data;
    }

    var list = [];
    for (var i = 0; i < items.length; i++) {
        var it = unwrapResource(items[i]);
        if (!it) continue;

        var categories = [];
        if (it.categories) {
            for (var j = 0; j < it.categories.length; j++) {
                if (it.categories[j] && it.categories[j].name) categories.push(String(it.categories[j].name));
            }
        }

        var desc = categories.join(", ");
        if (it.latest_chapter && it.latest_chapter.chapter_number) {
            desc = desc ? desc + " - " : "";
            desc += "Chương " + it.latest_chapter.chapter_number;
        }

        list.push({
            name:        it.title,
            link:        BASE_URL + "/novels/" + it.slug,
            cover:       storageUrl(it.cover_image),
            description: desc,
            host:        BASE_URL
        });
    }

    var nextPath = null;
    if (pageJson.props && pageJson.props.novels && pageJson.props.novels.next_page_url) {
        var nextUrl = String(pageJson.props.novels.next_page_url).replace(/&amp;/g, "&");
        nextPath = nextUrl.indexOf(BASE_URL) === 0 ? nextUrl.substring(BASE_URL.length) : nextUrl;
    }

    return nextPath ? Response.success(list, nextPath) : Response.success(list);
}
