load('config.js');

function execute(input) {
    // Nếu input là URL thì fetch API JSON
    if (typeof input === 'string') {
        if (input.startsWith('/')) input = BASE_URL + input;
        const resp = fetch(input);
        if (!resp.ok) return null;
        input = resp.json();
    }

    if (typeof input !== 'object' || !input.story) return null;

    const story = input.story;
    const translate = input.translate || {};
    const categories = input.categories || [];

    let cover = story.image;
    if (cover && !cover.startsWith('http')) cover = BASE_URL + cover;

    // Thể loại
    const genres = categories.map(cat => ({
        title: cat.categoryName,
        input: `/api/public/v2/stories-by-category/${cat.id}?pageNo=0&pageSize=20`,
        script: 'gen2.js'
    }));

    // Chi tiết mô tả ngắn gọn
    const detail = [
        `Cập nhật: ${input.elapsed || 'Không rõ'}`,
        `Tác giả: ${story.authorName || 'Không rõ'}`,
        `Lượt xem: ${story.totalView || 0}`,
        `Team: ${translate.teamName || 'Không rõ'}`,
        `Trạng thái: ${story.state === 1 ? 'Đang ra' : 'Trọn bộ'}`,
    ].join('<br>');

    return Response.success({
        name: story.name,
        cover: cover,
        author: story.authorName || '',
        description: (story.description || '').replace(/\r?\n+/g, '<br>').trim(),
        detail: detail,
        genres: genres,
        host: BASE_URL
    });
}

