load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/api/public/categories");
    if (!response.ok) return null;

    let json = response.json();
    const result = [];

    json.forEach(e => {
        if (
            e.id &&
            typeof e.id === 'number' &&
            e.categoryName &&
            e.categoryName.trim() !== '' &&
            e.url &&
            e.url !== "null" &&
            e.url.trim() !== ''
        ) {
            result.push({
                title: e.categoryName,
                input: "/api/public/v2/stories-by-category/" + e.id + "?pageNo=0&pageSize=20",
                script: "gen2.js"
            });
        }
    });

    return Response.success(result);
}
