load('config.js');

function execute(url, page) {
    let currentPage = page ? parseInt(page) : 0;

    let fullUrl = url.startsWith('http') ? url : BASE_URL + url;

    if (!fullUrl.includes('pageNo=')) {
        fullUrl += (fullUrl.includes('?') ? '&' : '?') + 'pageNo=' + currentPage + '&pageSize=20';
    } else {
        fullUrl = fullUrl.replace(/pageNo=\d+/, 'pageNo=' + currentPage);
    }

    let response = fetch(fullUrl);
    if (!response.ok) return null;

    let json = response.json();
    let list = json.content;
    let data = [];

    list.forEach(item => {
        let cover = item.image;
        if (cover && !cover.startsWith('http')) cover = BASE_URL + cover;

        data.push({
            name: item.name,
            link: BASE_URL + "/api/public/v2/" + item.url,
            cover: cover,
            description: item.authorName || '',
            host: BASE_URL
        });
    });

    // next page nếu json.next == true
    let next = json.next ? String(currentPage + 1) : null;

    return Response.success(data, next);
}
