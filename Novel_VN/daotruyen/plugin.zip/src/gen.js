load('config.js');

function execute(url, page) {
    let currentPage = page ? parseInt(page) : 0;
    let fullUrl = url.startsWith('http') ? url : BASE_URL + url;
    if (!fullUrl.includes('pageNo=')) {
        fullUrl += (fullUrl.includes('?') ? '&' : '?') + 'pageNo=' + currentPage + '&pageSize=8';
    } else {
        fullUrl = fullUrl.replace(/pageNo=\d+/, 'pageNo=' + currentPage);
    }

    let response = fetch(fullUrl);
    if (!response.ok) return null;

    let json = response.json();
    if (!json.content) return null;

    let data = [];
    json.content.forEach(item => {
        let story = item.story;
        let slug = item.slug;
        let cover = item.imageSrc;
        if (cover && !cover.startsWith('http')) cover = BASE_URL + cover;

        data.push({
    name: story.name,
    link: BASE_URL + "/api/public/v2/" + slug,
    cover: cover,
    description: item.timeElapsed,
    host: BASE_URL
});

    });

    let next = json.last === false ? String(currentPage + 1) : null;

    return Response.success(data, next);
}
