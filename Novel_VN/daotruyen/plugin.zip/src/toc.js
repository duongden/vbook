load('config.js');

function execute(url) {
    if (!url.startsWith('http')) url = BASE_URL + url;

    const response = fetch(url);
    if (!response.ok) return null;

    const json = response.json();
    const chapters = json.chapters;
    const story = json.story;

    if (!story || !chapters || !Array.isArray(chapters)) return null;

    const slug = story.url;
    const data = chapters.map(chap => ({
        name: chap.title || 'Chương ' + chap.chapterNumber,
        url: BASE_URL + '/api/public/v2/' + slug + '/' + chap.chapterNumber,
        host: BASE_URL
    }));

    return Response.success(data);
}
