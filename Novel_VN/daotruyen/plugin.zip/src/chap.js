load('config.js');

function execute(url) {
    if (url.indexOf('http') !== 0) {
        url = BASE_URL + url;
    }

    var response = fetch(url);
    if (!response.ok) return null;

    var json = response.json();
    var content = (json.chapter && json.chapter.paragraph) || json.data || '';

    return Response.success(cleanHtml(content));
}

function cleanHtml(htm) {
  return htm
    // 1) newline → <br/>
    .replace(/[\r\n]+/g, '<br/>')
    // 2) ký tự đặc biệt
    .replace(/ƣ/g, 'ư')
    .replace(/&(nbsp|amp|quot|lt|gt);/g, '')
    // 3) link, slash thừa
    .replace(/<a[^>]*>.*?<\/a>/g, '')
    .replace(/\//g, '')
    // 4) gom <br/> liên tiếp, trimm đầu-cuối
    .replace(/(<br\/>\s*){2,}/g, '<br/>')
    .replace(/^(<br\/>\s*)+|(<br\/>\s*)+$/g, '');
}

