function execute() {
    return Response.success([
        {
            title: "Mới cập nhật",
            input: "/api/public/stories",
            script: "gen.js"
        }
    ]);
}
