function execute() {
    return Response.success([
        { title: "玄幻", input: "/class/1_", script: "zen.js" },
        { title: "武侠", input: "/class/2_", script: "zen.js" },
        { title: "都市", input: "/class/3_", script: "zen.js" },
        { title: "历史", input: "/class/4_", script: "zen.js" },
        { title: "侦探", input: "/class/5_", script: "zen.js" },
        { title: "游戏", input: "/class/6_", script: "zen.js" },
        { title: "科幻", input: "/class/7_", script: "zen.js" },
        { title: "女生", input: "/class/8_", script: "zen.js" },
        { title: "精品", input: "/class/10_", script: "zen.js" }
    ]);
}