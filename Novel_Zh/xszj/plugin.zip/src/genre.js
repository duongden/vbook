function execute() {
    return Response.success([
        { title: "社会", input: "/c/2", script: "zen.js" },
        { title: "豪门", input: "/c/3", script: "zen.js" },
        { title: "现代", input: "/c/4", script: "zen.js" },
        { title: "古代", input: "/c/5", script: "zen.js" },
        { title: "穿越", input: "/c/6", script: "zen.js" },
        { title: "玄幻", input: "/c/7", script: "zen.js" },
        { title: "悬疑", input: "/c/8", script: "zen.js" },
        { title: "武侠", input: "/c/9", script: "zen.js" },
        { title: "女生", input: "/c/17", script: "zen.js" }
    ]);
}
