function execute() {
    return Response.success([
        {title: "玄幻", input: "1", script: "zen.js"},
        {title: "武侠", input: "2", script: "zen.js"},
        {title: "都市", input: "3", script: "zen.js"},
        {title: "历史", input: "4", script: "zen.js"},
        {title: "网游", input: "5", script: "zen.js"},
        {title: "科幻", input: "6", script: "zen.js"},
        {title: "女生", input: "7", script: "zen.js"},
        {title: "完本", input: "0", script: "zen.js"}
    ]);
}