let BASE_URL = 'https://www.a26b53.lol';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}