load('config.js');
function execute() {
    return Response.success([
        {title: "首页",   input: BASE_URL,                          script: "gen.js"},
        {title: "玄幻小说", input: BASE_URL + "/sort-1-1/",         script: "gen.js"},
        {title: "仙侠小说", input: BASE_URL + "/sort-2-1/",         script: "gen.js"},
        {title: "都市小说", input: BASE_URL + "/sort-3-1/",         script: "gen.js"},
        {title: "历史小说", input: BASE_URL + "/sort-4-1/",         script: "gen.js"},
        {title: "游戏小说", input: BASE_URL + "/sort-5-1/",         script: "gen.js"},
        {title: "科幻小说", input: BASE_URL + "/sort-6-1/",         script: "gen.js"},
        {title: "言情小说", input: BASE_URL + "/sort-7-1/",         script: "gen.js"},
        {title: "同人小说", input: BASE_URL + "/sort-8-1/",         script: "gen.js"},
        {title: "灵异小说", input: BASE_URL + "/sort-9-1/",         script: "gen.js"},
        {title: "奇幻小说", input: BASE_URL + "/sort-10-1/",        script: "gen.js"},
        {title: "竞技小说", input: BASE_URL + "/sort-11-1/",        script: "gen.js"},
        {title: "武侠小说", input: BASE_URL + "/sort-12-1/",        script: "gen.js"},
        {title: "军事小说", input: BASE_URL + "/sort-13-1/",        script: "gen.js"},
        {title: "校园小说", input: BASE_URL + "/sort-14-1/",        script: "gen.js"},
        {title: "官场小说", input: BASE_URL + "/sort-15-1/",        script: "gen.js"}
    ]);
}