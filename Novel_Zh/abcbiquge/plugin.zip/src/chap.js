load('config.js');
function execute(url) {
    // Normalize domain
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.indexOf("http") !== 0) url = BASE_URL + url;

    var response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);

    var doc = response.html();

    // Primary content selector: #nr1 (mobile site)
    var content = doc.select("#nr1").first();

    // Fallback selectors
    if (!content || content.html().trim() === "") {
        content = doc.select("#content, div.chapter_con, div.readcontent, div#chaptercontent").first();
    }

    if (!content) return Response.error("Không tìm thấy nội dung chương");

    // Clean noise
    content.select("script, style, div.ads, div[id^='ad'], a[href^='/wapbook-']").remove();

    var htm = content.html();
    if (!htm || htm.trim() === "") return Response.error("Nội dung trống");

    // Normalize whitespace
    htm = htm.replace(/&nbsp;/g, " ");
    htm = htm.replace(/<br\s*\/?>/gi, "<br>");

    return Response.success(htm);
}