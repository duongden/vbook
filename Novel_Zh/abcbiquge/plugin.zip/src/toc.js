load('config.js');
function execute(url) {
    if (!url) url = BASE_URL + "/wapbook-262_1/";

    // Normalize domain
    if (url.indexOf("http") !== 0) url = BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
    url = url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
    if (url.slice(-1) !== '/') url += '/';

    // Extract book ID from /info-{id}/ or /wapbook-{id}[_-].../ patterns
    var bookId = "";
    var infoMatch = url.match(/\/info-(\d+)\//);
    var wapMatch  = url.match(/\/wapbook-(\d+)[_\-]/);
    if (infoMatch) {
        bookId = infoMatch[1];
    } else if (wapMatch) {
        bookId = wapMatch[1];
    }

    if (!bookId) return Response.error("Không xác định được book ID từ URL: " + url);

    // Chapters use dash separator: /wapbook-{id}-{chapId}/
    // TOC pages use underscore: /wapbook-{id}_{page}/
    var chapPattern = new RegExp("^\\/wapbook-" + bookId + "-\\d+\\/$");

    var data = [];
    var seen = {};
    var page = 1;

    while (true) {
        var tocUrl = BASE_URL + "/wapbook-" + bookId + "_" + page + "/";
        var response = fetch(tocUrl);
        if (!response.ok) break;

        var doc = response.html();
        var pageData = [];

        doc.select("a[href]").forEach(function(e) {
            var href = e.attr("href") + "";
            var name = e.text().trim() + "";
            if (!href || !name) return;
            // Normalize to absolute URL
            var chapUrl = href.indexOf("http") === 0 ? href : BASE_URL + href;
            // Match chapter pattern; also try underscore separator as fallback
            var isChap = chapPattern.test(href) ||
                href.indexOf("/wapbook-" + bookId + "-") === 0;
            if (!isChap) return;
            if (seen[chapUrl]) return;
            seen[chapUrl] = true;
            pageData.push({ name: name, url: chapUrl, host: BASE_URL });
        });

        if (pageData.length === 0) break;
        for (var i = 0; i < pageData.length; i++) data.push(pageData[i]);

        // Check if there's a next TOC page
        var hasNext = false;
        var nextEl = doc.select("a:contains(下页), a:contains(下一页)").last();
        if (nextEl) {
            var nextHref = nextEl.attr("href") + "";
            if (nextHref && nextHref.indexOf("#") === -1 && nextHref.length > 1) {
                hasNext = true;
            }
        }
        if (!hasNext) break;
        page++;
    }

    if (data.length === 0) return Response.error("Không tìm thấy danh sách chương");
    return Response.success(data);
}
