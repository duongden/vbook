load('config.js');
function execute(key, page) {
    if (!page) page = "1";

    // Search URL for mobile site
    var searchUrl = BASE_URL + "/modules/article/waps.php";
    var response = fetch(searchUrl, {
        queries: {
            keyword: key,
            page: page
        }
    });

    if (!response.ok) {
        // Fallback to desktop search
        response = fetch(BASE_URL + "/modules/article/search.php?searchkey=" + key);
        if (!response.ok) return Response.error("Tìm kiếm thất bại: " + response.status);
    }

    var doc = response.html();
    var data = [];

    // Mobile search results: div.line with a.blue for title
    doc.select("div.line").forEach(function(e) {
        var a = e.select("a.blue, a[href^='/info-'], a[href^='/wapbook-']").first();
        if (!a) return;
        var name = a.text().trim();
        var link = a.attr("href");
        if (!name || !link) return;
        // Prefer info pages over TOC pages
        link = link.replace(/\/wapbook-(\d+)\/$/, "/info-$1/");
        if (link.indexOf("http") !== 0) link = BASE_URL + link;

        var cover = "";
        var imgEl = e.select("img").first();
        if (imgEl) {
            cover = imgEl.attr("src");
            if (cover && cover.indexOf("http") !== 0) cover = BASE_URL + cover;
        }

        var desc = "";
        var authorEl = e.select("a[href^='/author/']").first();
        if (authorEl) desc = authorEl.text().trim();

        data.push({ name: name, link: link, cover: cover, description: desc, host: BASE_URL });
    });

    // Fallback: desktop search table layout
    if (data.length === 0) {
        doc.select("#hotcontent > table > tbody > tr").forEach(function(e) {
            var a = e.select("td.odd a, td a[href]").first();
            if (!a) return;
            var name = a.text().trim();
            var link = a.attr("href");
            if (!name || !link) return;
            if (link.indexOf("http") !== 0) link = BASE_URL + link;
            var desc = e.select("td:nth-child(3)").first();
            data.push({
                name: name,
                link: link,
                description: desc ? desc.text().trim() : "",
                host: BASE_URL
            });
        });
    }

    // Pagination
    var next = "";
    var nextEl = doc.select("a:contains(下页), a:contains(下一页)").last();
    if (nextEl && nextEl.size() > 0) {
        next = String(parseInt(page) + 1);
    }

    if (data.length === 0) return Response.error("Không tìm thấy kết quả");
    return Response.success(data, next);
}