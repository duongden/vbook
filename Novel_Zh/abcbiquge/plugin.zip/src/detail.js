load('config.js');
function execute(url) {
    url = url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
    if (url.indexOf("http") !== 0) url = BASE_URL + url;
    if (url.charAt(url.length - 1) !== '/') url += '/';

    // Convert wapbook TOC URL to detail URL if needed
    var detailUrl = url.replace(/\/wapbook-(\d+)\/$/, "/info-$1/");

    var response = fetch(detailUrl);
    if (!response.ok) return Response.error("HTTP " + response.status);

    var doc = response.html();
    var txt2 = doc.select("div.block_txt2");

    // Title: <div class="block_txt2"><p><a><h2>title</h2></a></p>
    var name = txt2.select("h2").text().trim() + "";

    // Cover: <div class="block_img2"><img src="..."/>
    var coverEl = doc.select("div.block_img2 img").first();
    var cover = coverEl ? coverEl.attr("src") + "" : "";
    if (cover && cover.indexOf("http") !== 0) cover = BASE_URL + cover;

    // Author: <p>作者：<a href="/author/...">name</a></p>
    var author = txt2.select("a[href*='author']").text().trim() + "";

    // Category: <p>分类：<a href="/sort-X-1/">name</a></p>
    var category = txt2.select("a[href*='sort-']").text().trim() + "";

    // Status: <p>状态：连载中</p>
    var statusEl = txt2.select("p:contains(状态)").first();
    var statusText = statusEl ? statusEl.text().replace("状态：", "").trim() + "" : "";
    var ongoing = statusText.indexOf("完结") === -1;

    // Update date: <p>更新：2021-09-25</p>
    var updateEl = txt2.select("p:contains(更新)").first();
    var updateText = updateEl ? updateEl.text().replace("更新：", "").trim() + "" : "";

    // Latest chapter: <p>最新：<a href="...">chapter name</a></p>
    var latestEl = txt2.select("p:contains(最新) a").first();
    var latest = latestEl ? latestEl.text().trim() + "" : "";

    // Description: only <div class="intro_info">
    var descEl = doc.select("div.intro_info").first();
    var description = descEl ? descEl.html() + "" : "";

    // detail field shown under book info
    var detail = "";
    if (author)     detail += "作者：" + author + "<br>";
    if (category)   detail += "分类：" + category + "<br>";
    if (statusText) detail += "状态：" + statusText + "<br>";
    if (updateText) detail += "更新：" + updateText + "<br>";
    if (latest)     detail += "最新：" + latest;

    // TOC URL
    var bookId = detailUrl.match(/\/info-(\d+)\//);
    var tocUrl = bookId ? BASE_URL + "/wapbook-" + bookId[1] + "/" : url;

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        ongoing: ongoing,
        host: BASE_URL
    });
}
