load('config.js');
function execute(url, page) {
    if (!url) url = BASE_URL + "/";
    if (!page) page = "1";

    // Normalize URL: ensure absolute and correct domain
    if (url.indexOf("http") !== 0) {
        url = BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
    }
    url = url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
    if (url.charAt(url.length - 1) !== '/') url += '/';

    // Category pages use pattern /sort-{id}-{page}/ e.g. /sort-1-2/
    // Replace trailing page number in URL
    var pageUrl = url;
    if (parseInt(page) > 1) {
        if (/-\d+\/$/.test(url)) {
            pageUrl = url.replace(/-\d+\/$/, '-' + page + '/');
        } else {
            pageUrl = url + page + '/';
        }
    }

    var response = fetch(pageUrl);
    if (!response.ok) return Response.error("HTTP " + response.status);

    var doc = response.html();
    var data = [];

    // Category pages: <p class="line"><a>[genre]</a><a class="blue" href="/info-X/">title</a>/author</p>
    var items = doc.select("p.line");

    if (items.size() > 0) {
        items.forEach(function(e) {
            var titleLink = e.select("a.blue").first();
            if (!titleLink) return;
            var name = titleLink.text().trim() + "";
            var link = titleLink.attr("href") + "";
            if (!name || !link) return;
            if (link.indexOf("http") !== 0) link = BASE_URL + link;
            var desc = "";
            var authorEl = e.select("a[href*='author']").first();
            if (authorEl) desc = authorEl.text().trim() + "";
            data.push({name: name, link: link, description: desc, host: BASE_URL});
        });
    } else {
        // Homepage: <div class="block"><ul><li><a>[genre]</a><a class="blue">title</a>/author</li></ul></div>
        doc.select("div.block ul li").forEach(function(e) {
            var titleLink = e.select("a.blue").first();
            if (!titleLink) return;
            var name = titleLink.text().trim() + "";
            var link = titleLink.attr("href") + "";
            if (!name || !link) return;
            if (link.indexOf("http") !== 0) link = BASE_URL + link;
            var desc = "";
            var authorEl = e.select("a[href*='author']").first();
            if (authorEl) desc = authorEl.text().trim() + "";
            data.push({name: name, link: link, description: desc, host: BASE_URL});
        });
    }

    // Pagination: next page href is /sort-{id}-{nextPage}/
    var next = "";
    if (data.length > 0) {
        var nextEl = doc.select("a:contains(下页), a:contains(下一页)").last();
        if (nextEl) {
            var href = nextEl.attr("href") + "";
            if (href && href.indexOf("#") === -1) {
                var m = href.match(/-(\d+)\/?$/);
                next = m ? m[1] : String(parseInt(page) + 1);
            }
        }
    }

    if (data.length === 0) return Response.error("Không tìm thấy truyện");
    return Response.success(data, next);
}
