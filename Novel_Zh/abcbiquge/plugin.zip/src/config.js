var BASE_URL = "http://m.abcbiquge.com";
var ENCODING = "utf-8";
try {
    if (CONFIG_URL) BASE_URL = CONFIG_URL;
} catch (e) {}