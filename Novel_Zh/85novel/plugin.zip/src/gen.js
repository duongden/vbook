load("config.js");

function execute(url) {
    if (url === "85novel_note") {
        return Response.error(
            "Không thể tìm kiếm bằng vbook được\n" +
            'Bản beta vào cài đặt của ext,\nkéo xuống dưới cùng và chỉnh\n\n' +
            'Bản cũ: let CONFIG_GENRE trong cài đặt extension:\n' +
            'full = đầy đủ\n' +
            'nam = Nam\n' +
            'nữ = Nữ\n' +
            'XB = Khác\n' +
            'ví dụ:let CONFIG_GENRE = "nữ" \n' +
            'Trang này chỉ là thông báo không thuộc web đâu, qua tab kế bên đi :d \n' +
            'Tải nhanh có thể bị khóa IP, nên giữ 1 luồng và độ trễ 30 giây.'
        );
    }

    let response = fetch(normalizeInput(url), { headers: HEADERS });
    if (!response.ok) return null;

    let doc = response.html();
    let data = parseBookList(doc);
    if (!data.length) data = parseHomeBooks(doc);

    let next = doc.select("a.pagination-btn.rounded-r-lg").first().attr("href");
    if (!next) {
        doc.select("a.pagination-btn").forEach(a => {
            if (!next && /page\d+/.test(a.attr("href") || "")) next = a.attr("href");
        });
    }

    return Response.success(data, next ? absUrl(next) : "");
}
