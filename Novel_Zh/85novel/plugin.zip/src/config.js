let BASE_URL = "https://www.85novel.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL.replace(/\/+$/, "");
    }
} catch (error) {
}

const UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36";

const HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-TW,zh;q=0.9,zh-CN;q=0.8,en;q=0.7",
    "Referer": BASE_URL + "/"
};

const JSON_HEADERS = {
    "User-Agent": UA,
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json"
};

const NO_COVER = BASE_URL + "/img/nocover.jpg";

function absUrl(url) {
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;
    if (url.charAt(0) !== "/") url = "/" + url;
    return BASE_URL + url;
}

function normalizeInput(url) {
    if (!url) return BASE_URL + "/";
    if (url.indexOf("http") === 0) return url;
    if (url.charAt(0) !== "/") url = "/" + url;
    return BASE_URL + url;
}

function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
}

function cleanHtml(html) {
    return (html || "")
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<style[\s\S]*?<\/style>/gi, "")
        .replace(/<ins[\s\S]*?<\/ins>/gi, "")
        .replace(/<div[^>]*(?:id="div-onead|id="_popIn|class="[^"]*\bins\b)[\s\S]*?<\/div>/gi, "")
        .replace(/<br\s*\/?>/gi, "<br>")
        .replace(/<\/p>\s*<p[^>]*>/gi, "<br><br>")
        .replace(/<p[^>]*>/gi, "")
        .replace(/<\/p>/gi, "")
        .replace(/&nbsp;/g, "")
        .replace(/(<br>\s*){3,}/g, "<br><br>")
        .replace(/^\s*(<br>\s*)+|(<br>\s*)+\s*$/g, "")
        .trim();
}

function parseBookList(doc) {
    let data = [];
    doc.select("div.flex.flex-col.gap-2").forEach(e => {
        let a = e.select("a[href^=/book/]").first();
        let title = cleanText(e.select("h3").first().text());
        let href = a.attr("href");
        if (!title || !href) return;

        let spans = [];
        e.select("span").forEach(span => {
            let text = cleanText(span.text()).replace(/^✍\s*/, "").replace(/著$/, "").trim();
            if (text && !/^\d+$/.test(text)) spans.push(text);
        });

        let author = spans.length ? spans[0] : cleanText(e.select(".ms-2").first().text()).replace(/著$/, "").trim();
        let meta = cleanText(e.select(".text-base-700").first().text()).replace(/^✍\s*/, "");
        let latest = cleanText(e.select("a.text-primary-400").first().text());
        let updated = cleanText(e.select(".text-base-600").last().text());
        let desc = cleanText(e.select("p.line-clamp-2, p.line-clamp-3").first().text());

        data.push({
            name: title,
            link: absUrl(href),
            cover: absUrl(e.select("img").first().attr("src")) || NO_COVER,
            description: desc,
            author: author,
            detail: [meta, latest ? "最新章節: " + latest : "", updated].filter(Boolean).join("<br>"),
            host: BASE_URL
        });
    });
    return data;
}

function parseSearchBooks(doc) {
    let data = [];
    doc.select("div.flex.flex-col.gap-2").forEach(e => {
        let a = e.select("a[href^=/book/]").first();
        let href = a.attr("href");
        let title = cleanText(e.select("h3").first().text());
        if (!title || !href || !/\/book\/\d+\.html$/.test(href)) return;

        let spans = [];
        e.select("span").forEach(span => {
            let text = cleanText(span.text()).replace(/^✍\s*/, "").replace(/著$/, "").trim();
            if (text) spans.push(text);
        });

        let author = spans.length ? spans[0] : "";
        let kind = spans.slice(2, 4).join(" ‧ ");
        let wordCount = spans.length > 4 ? spans[4] : "";
        let latest = cleanText(e.select("a").last().text());
        let desc = cleanText(e.select("p").first().text());

        data.push({
            name: title,
            link: absUrl(href),
            cover: absUrl(e.select("img").first().attr("src")) || NO_COVER,
            description: desc,
            author: author,
            detail: [kind, wordCount, latest ? "最新章節: " + latest : ""].filter(Boolean).join("<br>"),
            host: BASE_URL
        });
    });
    return data;
}

function parseHomeBooks(doc) {
    let data = [];
    doc.select("a[href^=/book/]").forEach(e => {
        let href = e.attr("href");
        if (!/\/book\/\d+\.html$/.test(href || "")) return;

        let title = cleanText(e.select("h3").first().text()) || cleanText(e.attr("title")) || cleanText(e.text());
        if (!title) return;

        let exists = data.some(item => item.link === absUrl(href));
        if (exists) return;

        let cover = e.select("img").first().attr("src");
        let author = cleanText(e.select("span.truncate").first().text());
        let desc = cleanText(e.select("p.line-clamp-3").first().text());
        data.push({
            name: title,
            link: absUrl(href),
            cover: absUrl(cover) || NO_COVER,
            description: [author, desc].filter(Boolean).join(" | "),
            host: BASE_URL
        });
    });
    return data;
}
