load("config.js");

function execute(key, page) {
    var url = page || (BASE_URL + "/search?k=" + encodeURIComponent(key));
    if (!page) {
        try {
            fetch(BASE_URL + "/search", { headers: HEADERS });
            sleep(1000);
        } catch (warmupError) {
        }
    }
    var response = fetch(url, { headers: HEADERS });
    var doc = null;

    if (response && response.ok) {
        doc = response.html();
    }
    if (!doc || isCloudflarePage(doc)) {
        doc = loadSearchDocument(url);
    }
    if (!doc) return Response.error("Không thể vượt qua xác minh Cloudflare khi tìm kiếm.");

    var data = parseSearchBooks(doc);
    if (!data.length) data = parseBookList(doc);
    if (!data.length) data = parseHomeBooks(doc);

    var next = doc.select("a.pagination-btn.rounded-r-lg").first().attr("href");
    return Response.success(data, next ? absUrl(next) : "");
}

function isCloudflarePage(doc) {
    var title = cleanText(doc.select("title").first().text());
    return /Just a moment|Attention Required|Cloudflare/i.test(title)
        || !doc.select("#head-search").size();
}

function loadSearchDocument(url) {
    if (typeof Engine === "undefined" || !Engine || typeof Engine.newBrowser !== "function") return null;

    var browser = null;
    try {
        browser = Engine.newBrowser();
        var doc = browser.launch(url, 15000);
        if (doc && isCloudflarePage(doc)) {
            sleep(8000);
            if (typeof browser.html === "function") doc = browser.html();
        }
        if (doc && doc.select && !isCloudflarePage(doc)) return doc;
    } catch (error) {
    } finally {
        try {
            if (browser && browser.close) browser.close();
        } catch (closeError) {
        }
    }
    return null;
}
