load("config.js");

const DETAIL_GENRE_MAP = {
    "男生小說": "/list/1/",
    "女生小說": "/list/2/",
    "文學刊物": "/list/3/",
    "玄幻奇幻": "/list/667/",
    "玄幻": "/list/667/",
    "奇幻": "/list/667/",
    "仙俠武俠": "/list/668/",
    "仙俠": "/list/668/",
    "武俠": "/list/668/",
    "都市生活": "/list/669/",
    "都市": "/list/669/",
    "歷史軍事": "/list/670/",
    "歷史": "/list/670/",
    "軍事": "/list/670/",
    "遊戲競技": "/list/671/",
    "遊戲": "/list/671/",
    "科幻未來": "/list/672/",
    "科幻": "/list/672/",
    "懸疑靈異": "/list/728/",
    "懸疑": "/list/728/",
    "靈異": "/list/728/",
    "次元宅萌": "/list/734/",
    "輕小說": "/list/734/",
    "諸天無限": "/list/735/",
    "古代言情": "/list/673/",
    "現代言情": "/list/674/",
    "浪漫青春": "/list/733/",
    "玄幻仙俠": "/list/675/",
    "科幻遊戲": "/list/736/",
    "靈異懸疑": "/list/737/",
    "文學藝術": "/list/741/",
    "人文社科": "/list/742/",
    "經管勵志": "/list/743/",
    "經典文學": "/list/744/",
    "出版小說": "/list/745/",
    "少兒教育": "/list/746/",
    "連載中": "/list/finish1/",
    "已完結": "/list/finish2/",
    "完結": "/list/finish2/"
};

function execute(url) {
    url = normalizeInput(url);
    let response = fetch(url, { headers: HEADERS });
    if (!response.ok) return null;

    let doc = response.html();
    let title = cleanText(doc.select("h1").first().text()) || cleanText(doc.select("meta[property=og:title]").first().attr("content")).replace(/\s*85小說網$/, "");
    let author = getAuthor(doc);
    let cover = getCover(doc, url);
    let meta = parseMeta(doc);
    let description = parseDescription(doc);
    let latestLink = doc.select("a[href*='/book/'].text-primary-400, a.c-item[href]").first();
    let latest = cleanText(latestLink.text());
    let latestUpdated = cleanText(doc.select(".flex.gap-3 .opacity-60").first().text());
    let tags = [];
    doc.select(".flex.flex-wrap.gap-3 span.bg-base-300").forEach(e => tags.push(cleanText(e.text())));
    let genres = buildGenres(meta, tags);
    let detail = [
        meta.category ? "分類: " + meta.category : "",
        meta.subCategory ? "題材: " + meta.subCategory : "",
        meta.words ? "字數: " + meta.words : "",
        meta.status ? "狀態: " + meta.status : "",
        meta.organized ? "整理: " + meta.organized : "",
        meta.changed ? "異動: " + meta.changed : "",
        tags.length ? "標籤: " + tags.join(", ") : "",
        latest ? "最新章節: " + latest : "",
    ].filter(Boolean).join("<br>");

    return Response.success({
        name: title,
        cover: cover,
        author: author,
        description: description,
        detail: "Tải nhanh sẽ bị ban IP, set 1 luồng 30s" + '<br>' + detail,
        host: BASE_URL,
        genres: genres
    });
}

function getCover(doc, url) {
    let cover = doc.select("img[alt]").first().attr("src")
        || doc.select("meta[property=og:image]").first().attr("content");
    cover = normalizeCoverUrl(cover);
    if (cover) return cover;

    let match = url.match(/\/book\/(\d+)\.html/);
    return match ? BASE_URL + "/cover/" + match[1] + ".jpg" : NO_COVER;
}

function getAuthor(doc) {
    let author = cleanText(doc.select(".hero-content .flex.items-baseline span, .flex.flex-col.gap-1 > span").first().text())
        .replace(/著/g, "")
        .trim();
    if (author) return author;

    let title = cleanText(doc.select("title").first().text());
    let match = title.match(/\(([^)]+)\)/);
    return match ? match[1] : "";
}

function normalizeCoverUrl(url) {
    url = cleanText(url).replace(/^https:https:\/\//, "https://").replace(/^http:https:\/\//, "https://");
    if (!url || /nocover\.jpg$/i.test(url)) return "";
    return absUrl(url);
}

function parseMeta(doc) {
    let spans = [];
    doc.select(".hero-content .text-base-700 span, .w-full.z-20 .text-base-700 span").forEach(e => {
        let text = cleanText(e.text());
        if (text) spans.push(text);
    });

    let values = spans.filter(text => text !== "整理:" && text !== "異動:");
    let category = "";
    let subCategory = "";
    let words = "";
    let status = "";

    values.forEach(text => {
        if (!words && /(?:萬字|字)$/.test(text)) {
            words = text;
        } else if (!status && /(?:連載中|已完結|完結|連載)/.test(text)) {
            status = text;
        } else if (!category) {
            category = text;
        } else if (!subCategory) {
            subCategory = text;
        }
    });

    return {
        category: category,
        subCategory: subCategory,
        words: words,
        status: status,
        organized: valueAfterLabel(spans, "整理:"),
        changed: valueAfterLabel(spans, "異動:")
    };
}

function valueAfterLabel(items, label) {
    let index = items.indexOf(label);
    return index >= 0 && items.length > index + 1 ? items[index + 1] : "";
}

function parseDescription(doc) {
    let paragraphs = [];
    doc.select(".overscroll-contain p").forEach(p => {
        let text = cleanText(p.text());
        if (text) paragraphs.push(text);
    });
    if (paragraphs.length) return paragraphs.join("<br><br>");

    return cleanText(doc.select("meta[property=og:description]").first().attr("content"));
}

function buildGenres(meta, tags) {
    let data = [];
    let seen = {};
    addDetailGenre(data, seen, meta.category);
    addDetailGenre(data, seen, meta.subCategory);
    addDetailGenre(data, seen, meta.status);
    tags.forEach(tag => addDetailGenre(data, seen, tag));
    return data;
}

function addDetailGenre(data, seen, title) {
    title = cleanText(title);
    if (!title || seen[title]) return;
    seen[title] = true;

    let input = DETAIL_GENRE_MAP[title];
    if (input) {
        data.push({ title: title, input: input, script: "gen.js" });
    } else {
        data.push({ title: title, input: title, script: "search.js" });
    }
}
