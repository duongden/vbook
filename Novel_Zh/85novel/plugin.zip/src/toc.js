load("config.js");

const TOC_PAGE_SIZE = 200;
const TOC_PAGE_DELAY = 2500;

function execute(url) {
    let page = extractTocPage(normalizeInput(url));
    url = page.url;
    let response = fetch(url, { headers: HEADERS });
    if (!response.ok) return null;

    let html = response.text() || "";
    let cookie = "";
    try {
        cookie = response.request.headers.cookie || "";
    } catch (error) {
    }
    let token = extractXsrfToken(html);
    let chapters = [];
    let seen = {};

    if (token) {
        cookie = "_xsrf=" + token + (cookie ? "; " + cookie : "");
        let postHeaders = {
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": url,
            "Cookie": cookie
        };

        let total = page.end || fetchChapterTotal(url, token, postHeaders) || 10000;
        let startAt = page.start || 1;
        for (let start = startAt; start <= total; start += TOC_PAGE_SIZE) {
            if (start > startAt) sleep(TOC_PAGE_DELAY);
            let list = fetchChapterSlice(url, token, postHeaders, [start, Math.min(start + TOC_PAGE_SIZE - 1, total)]);
            list.forEach(ch => pushChapter(chapters, seen, ch.ChapterName, ch.ChapterUrl));
            if (list.length < TOC_PAGE_SIZE) break;
        }
    }

    if (!chapters.length) {
        let doc = Html.parse(html);
        parseHtmlChapters(doc, chapters, seen);
    }

    return Response.success(chapters);
}

function extractTocPage(url) {
    let marker = "#toc=";
    let index = url.indexOf(marker);
    if (index < 0) return { url: url, start: 0, end: 0 };

    let parts = url.substring(index + marker.length).split("-");
    return {
        url: url.substring(0, index),
        start: parseInt(parts[0]) || 0,
        end: parseInt(parts[1]) || 0
    };
}

function extractXsrfToken(html) {
    let match = html.match(/Login\([^,]+,\s*'([^']+)'/);
    if (match) return match[1];

    let marker = "Login(";
    let index = html.indexOf(marker);
    if (index < 0) return "";
    let start = html.indexOf("'", index);
    if (start < 0) return "";
    let end = html.indexOf("'", start + 1);
    if (end < 0) return "";
    return html.substring(start + 1, end);
}

function fetchChapterTotal(url, token, headers) {
    let res = fetch(url + "?_xsrf=" + encodeURIComponent(token), {
        method: "POST",
        headers: headers,
        body: JSON.stringify({ action: "auth" })
    });
    if (!res.ok) return 0;

    let data = JSON.parse(res.text());
    return parseInt((((data || {}).result || {}).chapters || 0)) || 0;
}

function fetchChapterSlice(url, token, headers, slice) {
    let res = fetch(url + "?_xsrf=" + encodeURIComponent(token), {
        method: "POST",
        headers: headers,
        body: JSON.stringify({ action: "chapters", slice: slice })
    });
    if (!res.ok) return [];

    let data = JSON.parse(res.text());
    return (((data || {}).result || {}).chapters || []);
}

function parseHtmlChapters(doc, chapters, seen) {
    doc.select("a[href*='.html']").forEach(e => {
        let href = e.attr("href");
        let name = cleanText(e.text());
        if (/^\d+\/\d+\.html$/.test(href || "") && name) {
            pushChapter(chapters, seen, name, href);
        }
    });
}

function pushChapter(chapters, seen, name, href) {
    if (!name || !href) return;
    let key = href.replace(/^\/?book\//, "");
    if (seen[key]) return;
    seen[key] = true;
    chapters.push({ name: name, url: absUrl("/book/" + key), host: BASE_URL });
}
