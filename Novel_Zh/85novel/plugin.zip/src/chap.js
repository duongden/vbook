load("config.js");

function execute(url) {
    let response = fetch(normalizeInput(url), { headers: HEADERS });
    if (!response.ok) return null;

    let doc = response.html();
    let paragraphs = [];
    doc.select(".font-mono p").forEach(e => {
        let text = cleanText(e.text());
        if (text) paragraphs.push(text);
    });
    if (paragraphs.length) return Response.success(paragraphs.join("<br><br>"));

    let content = doc.select(".font-mono").first().html();

    return Response.success(cleanHtml(content));
}
