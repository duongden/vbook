load("config.js");

function execute() {
    return Response.success([
        { title: "最新更新", input: "/list/index", script: "gen.js" },
        { title: "男生小說", input: "/list/1/", script: "gen.js" },
        { title: "女生小說", input: "/list/2/", script: "gen.js" },
        { title: "文學刊物", input: "/list/3/", script: "gen.js" },
        { title: "排行榜", input: "/top/index", script: "gen.js" },
        { title: "NOTE", input: "85novel_note", script: "gen.js" }
    ]);
}
