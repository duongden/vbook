load("config.js");

function execute(url) {
    url = normalizeInput(url);
    let response = fetch(url, { headers: HEADERS });
    if (!response.ok) return Response.success([url]);

    let html = response.text() || "";
    let token = extractXsrfToken(html);
    if (!token) return Response.success([url]);

    let total = fetchChapterTotal(url, token, response);
    if (!total) return Response.success([url]);

    return Response.success([url + "#toc=1-" + total]);
}

function fetchChapterTotal(url, token, response) {
    let cookie = "";
    try {
        cookie = response.request.headers.cookie || "";
    } catch (error) {
    }
    cookie = "_xsrf=" + token + (cookie ? "; " + cookie : "");

    let res = fetch(url + "?_xsrf=" + encodeURIComponent(token), {
        method: "POST",
        headers: {
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": url,
            "Cookie": cookie
        },
        body: JSON.stringify({ action: "auth" })
    });
    if (!res.ok) return 0;

    let data = JSON.parse(res.text());
    return parseInt((((data || {}).result || {}).chapters || 0)) || 0;
}

function extractXsrfToken(html) {
    let match = html.match(/Login\([^,]+,\s*'([^']+)'/);
    if (match) return match[1];

    let marker = "Login(";
    let index = html.indexOf(marker);
    if (index < 0) return "";
    let start = html.indexOf("'", index);
    if (start < 0) return "";
    let end = html.indexOf("'", start + 1);
    if (end < 0) return "";
    return html.substring(start + 1, end);
}
