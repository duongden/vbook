load("config.js");

const STATIC_GENRES = [
    { title: "男生小說 - 玄幻奇幻", input: "/list/667/" },
    { title: "男生小說 - 仙俠武俠", input: "/list/668/" },
    { title: "男生小說 - 都市生活", input: "/list/669/" },
    { title: "男生小說 - 歷史軍事", input: "/list/670/" },
    { title: "男生小說 - 遊戲競技", input: "/list/671/" },
    { title: "男生小說 - 科幻未來", input: "/list/672/" },
    { title: "男生小說 - 懸疑靈異", input: "/list/728/" },
    { title: "男生小說 - 次元宅萌", input: "/list/734/" },
    { title: "男生小說 - 諸天無限", input: "/list/735/" },
    { title: "男生小說 - 其他小說", input: "/list/738/" },
    { title: "女生小說 - 古代言情", input: "/list/673/" },
    { title: "女生小說 - 現代言情", input: "/list/674/" },
    { title: "女生小說 - 浪漫青春", input: "/list/733/" },
    { title: "女生小說 - 玄幻仙俠", input: "/list/675/" },
    { title: "女生小說 - 科幻遊戲", input: "/list/736/" },
    { title: "女生小說 - 靈異懸疑", input: "/list/737/" },
    { title: "女生小說 - 其他小說", input: "/list/739/" },
    { title: "文學刊物 - 文學藝術", input: "/list/741/" },
    { title: "文學刊物 - 人文社科", input: "/list/742/" },
    { title: "文學刊物 - 經管勵志", input: "/list/743/" },
    { title: "文學刊物 - 經典文學", input: "/list/744/" },
    { title: "文學刊物 - 出版小說", input: "/list/745/" },
    { title: "文學刊物 - 少兒教育", input: "/list/746/" },
    { title: "文學刊物 - 其他小說", input: "/list/749/" },
    { title: "完結狀態 - 全部", input: "/list/index" },
    { title: "完結狀態 - 連載中", input: "/list/finish1/" },
    { title: "完結狀態 - 已完結", input: "/list/finish2/" }
];

function execute() {
    let channel = getGenreFilter();
    let data = [];
    let seen = {};

    STATIC_GENRES.forEach(item => addGenre(data, seen, item.title, item.input));

    ["/list/index", "/top/index"].forEach(path => {
        try {
            let response = fetch(BASE_URL + path, { headers: HEADERS });
            if (!response.ok) return;

            parseGenreBlocks(response.html()).forEach(item => {
                addGenre(data, seen, item.title, item.input);
            });
        } catch (error) {
        }
    });

    return Response.success(filterGenres(data, channel).map(item => ({
        title: item.title,
        input: item.input,
        script: "gen.js"
    })));
}

function parseGenreBlocks(doc) {
    let data = [];
    let seen = {};

    doc.select("div.flex.flex-col.gap-3").forEach(block => {
        let prefix = normalizePrefix(block.select("h2").first().text());
        if (!prefix) return;

        block.select("a").forEach(a => {
            let href = a.attr("href");
            if (!href || !/^\/(?:list|top)\//.test(href)) return;

            let text = cleanText(a.text());
            if (!text) return;

            let title = buildTitle(prefix, text);
            let key = href + "|" + title;
            if (seen[key]) return;
            seen[key] = true;

            data.push({ title: title, input: href });
        });
    });

    return data;
}

function addGenre(data, seen, title, input) {
    let key = input + "|" + title;
    if (seen[key]) return;
    seen[key] = true;
    data.push({ title: title, input: input });
}

function filterGenres(data, channel) {
    if (channel === "nam") return data.filter(item => isRankingGenre(item) || isMaleGenre(item.title)).map(cleanChannelTitle);
    if (channel === "nữ") return data.filter(item => isRankingGenre(item) || isFemaleGenre(item.title)).map(cleanChannelTitle);
    if (channel === "XB") return data.filter(item => isRankingGenre(item) || (!isMaleGenre(item.title) && !isFemaleGenre(item.title))).map(cleanChannelTitle);
    return data;
}

function isRankingGenre(item) {
    return !!(item && /^\/top\//.test(item.input || ""));
}

function getGenreFilter() {
    var value = "";
    try {
        if (typeof CONFIG_GENRE !== "undefined") value = normalizeGenreFilter(CONFIG_GENRE);
    } catch (error) {
    }
    if (value) return value;

    value = normalizeGenreFilter(getConfigValue("CONFIG_GENRE", ""));
    if (value) return value;

    var oldValue = getConfigValue("genre_channel", "");
    if (oldValue === "1") return "nam";
    if (oldValue === "2") return "nữ";
    return "full";
}

function normalizeGenreFilter(value) {
    if (value === null || typeof value === "undefined") return "";
    var text = (value + "").replace(/^\s+|\s+$/g, "");
    var key = text.toLowerCase();
    if (key === "full") return "full";
    if (key === "nam") return "nam";
    if (key === "nữ" || key === "nu") return "nữ";
    if (key === "xb") return "XB";
    return "";
}

function isMaleGenre(title) {
    return /^男生小說(?:\s*-|$)/.test(title || "");
}

function isFemaleGenre(title) {
    return /^女生小說(?:\s*-|$)/.test(title || "");
}

function cleanChannelTitle(item) {
    return {
        title: item.title.replace(/^男生小說\s*-\s*/, "").replace(/^女生小說\s*-\s*/, ""),
        input: item.input
    };
}

function getConfigValue(key, fallback) {
    try {
        let value = localConfig.getItem(key);
        if (value) return (value + "").replace(/^\s+|\s+$/g, "");
    } catch (error) {
    }
    return fallback || "";
}

function normalizePrefix(text) {
    return cleanText(text)
        .replace(/\s+/g, " ")
        .replace(/[⌄∨]+$/g, "")
        .trim();
}

function buildTitle(prefix, text) {
    if (prefix === text) return text;
    return prefix + " - " + text;
}
