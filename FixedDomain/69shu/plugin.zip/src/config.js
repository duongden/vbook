//    var host = 'https://www.69shuba.com';
//let BASE_URL = 'https://69shuba.cx';
var BASE_URL = "https://69shuba.cx";
if (typeof CONFIG_URL !== "undefined" && CONFIG_URL.indexOf("69shuba.com") != -1) {
    BASE_URL = "https://69shuba.com";
}